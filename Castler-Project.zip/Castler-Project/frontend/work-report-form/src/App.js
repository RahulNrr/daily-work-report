import './App.css';
import EnteryForm from './components/EnteryForm'

function App() {
  return (
    <div className="App">
      <EnteryForm/>
    </div>
  );
}

export default App;
