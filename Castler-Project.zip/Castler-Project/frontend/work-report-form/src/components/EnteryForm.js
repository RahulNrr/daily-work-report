import {useState} from 'react'
import axios from 'axios';
// import Date from './Date'

const EnteryForm = () =>{
    const url = "";
    // const [name, setName] = useState();
    // const [date, setDate] = useState();
    // const [email, setEmail] = useState();
    // const [hours, setHours] = useState("8hrs");
    const [data, setData] = useState({
        name: "",
        email: "",
        data: "",
        workhours: "",
        description: ""
    })
     
    let errorMsg = document.getElementsByClassName("error")
    let succesIcons = document.getElementsByClassName("success-icon")
    let failureIcon = document.getElementsByClassName("failure-icon")
    

    const handle = (e) =>{
        const newdata = {...data}
        newdata[e.target.id] = e.target.value
        setData(newdata);
        console.log(newdata)
    }
  

    const handleClick = (e) => {
        axios.post(url,{
          name: data.name,
          date: data.date,
          email: data.email,
          workhours: data.workhours,
          description: data.description
        })
        .then(res=>{
            console.log(res.data)
        })

        let username = document.getElementById("name")
        let email = document.getElementById("email")
        let workhours = document.getElementById("work-hour")

    e.preventDefault();
    if (username.value === '') {
        errorMsg[0].innerHTML = "username can not be blank";
        failureIcon[0].style.opacity = "1";
        succesIcons[0].style.opacity = "0";
    } else {
        errorMsg[0].innerHTML = "";
        failureIcon[0].style.opacity = "0";
        succesIcons[0].style.opacity = "1";
    }
    if (email.value === '') {
        errorMsg[1].innerHTML = "email can not be blank";
        failureIcon[1].style.opacity = "1";
        succesIcons[1].style.opacity = "0";
    } else {
        errorMsg[1].innerHTML = "";
        failureIcon[1].style.opacity = "0";
        succesIcons[1].style.opacity = "1";
    }
    if (workhours.value === '') {
        errorMsg[3].innerHTML = "please enter your valid work hour";
        failureIcon[3].style.opacity = "1";
        succesIcons[3].style.opacity = "0";
    } else {
        errorMsg[3].innerHTML = "";
        failureIcon[3].style.opacity = "0";
        succesIcons[3].style.opacity = "1";
    }

;
    }
    return (
        <div className="container">
        <form onSubmit={(e)=>handleClick(e)}>
        <div className="social">
            <div className="title">Castler-daily work report</div>
        </div>
            <div>
                <label htmlFor="name">Name</label>
                <i className="fas fa-user"></i>
                <input type="name" name="username" value={data.name} onChange={(e)=>handle(e)} id="name" placeholder="Rahul Nagar"/>
                <i className="fas fa-exclamation-circle failure-icon"></i>
                <i className="fas fa-check-circle success-icon"></i>
                <div className="error"></div>
            </div>
            <div>
                <div>
                    <label htmlFor="email">Email</label>
                    <i className="fas fa-envelope"></i>
                    <input type="email" name="email" value={data.email} onChange={(e)=>handle(e)} id="email" placeholder="abc@gmail.com"/>
                    <i className="fas fa-exclamation-circle failure-icon"></i>
                    <i className="fas fa-check-circle success-icon"></i>
                    <div className="error"></div>
                </div>
            </div>
            <div>
                <label htmlFor="date">Date</label>
                <i className="fas fa"></i>
                <input type="date" name="date" id="date" value={data.date} onChange={(e)=>handle(e)} placeholder="DD MM YYYY"/>
                <i className="fas fa-exclamation-circle failure-icon"></i>
                <i className="fas fa-check-circle success-icon"></i>
                <div className="error"></div>
            </div>
            <div>
                <label htmlFor="work hour">Work hours</label>
                <i className="fas fa-"></i>
                <input type="hour" id="work-hour" name="work hour" value={data.hours} onChange={(e)=>handle(e)} />
                {/* <Date/> */}
                <i className="fas fa-exclamation-circle failure-icon"></i>
                <i className="fas fa-check-circle success-icon"></i>
                <div className="error"></div>
            </div>
            <div>
                <label htmlFor="Description">Description</label>
                <i className="fas fa-"></i>
                <input className="description-input" type="description" name="Description" value={data.description} onChange={(e)=>handle(e)} id="description" placeholder="Write something here"/>
                <i className="fas fa-exclamation-circle failure-icon"></i>
                <i className="fas fa-check-circle success-icon"></i>
                <div className="error"></div>
            </div>
             <div>
            </div>
            <button type="submit" id="submit" onSubmit={(e)=>handleClick(e)}>Submit</button>
        </form>
    </div>
      );
    }
export default EnteryForm;