require('dotenv').config();

const nodemailer = require("nodemailer");

(async function run() {
    console.log("Running my daily report")
    const transporter = nodemailer.createTransport({
        host: "smtp.gmail.com",
        port: 465,
        secure: true,
        auth: {
            user: process.env.MAIL_USER_EMAIL,
            pass: process.env.MAIL_USER_PASS
        }
    })

    let info = await transporter.sendMail({
        from: process.env.MAIL_FROM, 
        to: process.env.MAIL_TO, // ds040567@gmail.com
        subject: "Daily report work",
        html: `
          <h3>Working Hours</h3>
          <span>Min</span>
          <span>Max</span>
        `,
        // text: "Hey you got your daily work report notification",
        html: `
        <h3>Working Hours</h3>
          <span>Min</span>
          <span>Max</span>
        <p>"Hey you got your daily work report notification"</p>
        <a href="">Link</a>
        `,
       
    })

})();